//
//  PetPage.swift
//  GarbagePetz
//
//  Created by Alexander on 12/9/18.
//  Copyright © 2018 Will Hammond. All rights reserved.
//

import UIKit

class PetPage: UIViewController {
    
    let petConditionArr = ["Your pet is in excellent condition! Keep up the good work", "Good job! Your pet loves you. Keep it up!", "Your pet couldn't be happier. You are doing a great job recycling"]
    
    let recyclingSuggestionsArr = ["You are doing a good job. Just remember to always try and avoid plastic water bottles. Get a reusable bottle, it will save you money and it stores more water!", "Remember your compostables! Your pet says you are doing a good job but always keep in mind that it is helpful to properly dispose of items that could be handled better than normal trash."]
    
    @IBOutlet weak var petImageView: UIImageView!
    
    @IBOutlet weak var petConditionView: UITextView!
    
    @IBOutlet weak var petInteractButton: UIButton!
    
    @IBOutlet weak var recyclingSuggestionsView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        petImageView.loadGif(name: "gphanim")
        
        
        
    }
    
    
    
    @IBAction func onTapPetCondition(_ sender: Any) {
        let size = Int.random(in: 0..<petConditionArr.count)
        petConditionView.text = petConditionArr[size]
        
        let size2 = Int.random(in: 0..<recyclingSuggestionsArr.count)
        recyclingSuggestionsView.text = recyclingSuggestionsArr[size2]
        
    }
    
    
}



