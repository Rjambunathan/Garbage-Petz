//
//  ViewController.swift
//  GarbagePetz
//
//  Created by Will Hammond on 12/6/18.
//  Copyright © 2018 Will Hammond. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    var counter = 0;
    
    @IBOutlet weak var addWasteButton: UIButton!
    
    @IBOutlet weak var homeScreenWaste1: UILabel!
    
    @IBOutlet weak var homeScreenWaste2: UILabel!
    
    
    @IBOutlet weak var homeScreenWaste3: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        addWasteButton.layer.cornerRadius = 10
        
    // Waits for notification from Add Common Waste Item scene, then updates labels on homescreen
        NotificationCenter.default.addObserver(self, selector: #selector(updateLabel1(notification:)), name: NSNotification.Name.init("updateLabel1"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(updateLabel2(notification:)), name: NSNotification.Name.init("updateLabel2"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(updateLabel3(notification:)), name: NSNotification.Name.init("updateLabel3"), object: nil)
    }
    
    
    @objc func updateLabel1(notification: NSNotification){
        homeScreenWaste1.text = "Plastic Water Bottle"
    }
    
    @objc func updateLabel2(notification: NSNotification){
        homeScreenWaste3.text = "Banana Peel"
    }
    
    @objc func updateLabel3(notification: NSNotification){
        homeScreenWaste2.text = "Cardboard Container"
    }}

