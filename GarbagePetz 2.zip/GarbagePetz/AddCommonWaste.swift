//
//  AddCommonWaste.swift
//  GarbagePetz
//
//  Created by Alexander on 12/9/18.
//  Copyright © 2018 Will Hammond. All rights reserved.
//

import UIKit

class AddCommonWaste: UIViewController {
    


    @IBOutlet weak var commonWaste1: UIButton!
    
    @IBOutlet weak var commonWaste2: UIButton!
    
    @IBOutlet weak var commonWaste3: UIButton!
    
    @IBOutlet weak var createNewWasteButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        commonWaste1.layer.cornerRadius = 10
        commonWaste2.layer.cornerRadius = 10
        commonWaste3.layer.cornerRadius = 10
       createNewWasteButton.layer.cornerRadius = createNewWasteButton.bounds.size.height/2
        

       
    }
    
    @IBAction func sendCommonWaste1(_ sender: Any) {
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "updateLabel1"), object: nil)
    }
    
    @IBAction func sendCommonWaste2(_ sender: Any) {
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "updateLabel2"), object: nil)
    }
    
    @IBAction func sendCommonWaste3(_ sender: Any) {
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "updateLabel3"), object: nil)
    }
    
    
    
}
