//
//  CustomWaste.swift
//  GarbagePetz
//
//  Created by Alexander on 12/9/18.
//  Copyright © 2018 Will Hammond. All rights reserved.
//

import UIKit

class CustomWaste: UIViewController {
    
    @IBOutlet weak var createButton: UIButton!
    
    @IBOutlet weak var pickItemMaterial: UIButton!
    
    // Don't use this!!
    @IBOutlet weak var openMaterialsButton: UIButton!
    
    
    
    // Correct outlets
    @IBOutlet weak var itemMaterialButton: UIButton!
    
    @IBOutlet var materialsCollection: [UIButton]!
    
    // Outlets for second drop down

    @IBOutlet weak var itemSizeButton: UIButton!
    
    
    @IBOutlet var sizesOutletCollection: [UIButton]!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        createButton.layer.cornerRadius = createButton.bounds.size.height/2
        
        itemMaterialButton.layer.cornerRadius = itemMaterialButton.bounds.size.height/2
        
    }
    
    
    @IBAction func createdNewItem(_ sender: Any) {
    }
    
    
    
    //Use these!!
    
    @IBAction func itemMaterialTapped(_ sender: Any) {
        materialsCollection.forEach { (button) in
            UIView.animate(withDuration: 0.3, animations: {
                button.isHidden = !button.isHidden
                self.view.layoutIfNeeded()
            })
        }
    }
    

    @IBAction func materialsActions(_ sender: UIButton) {
        itemMaterialButton.setTitle(sender.titleLabel?.text, for: .normal)
        materialsCollection.forEach { (button) in
            UIView.animate(withDuration: 0.3, animations: {
                button.isHidden = !button.isHidden
                self.view.layoutIfNeeded()
            })
        }
    }
    
    // Actions for Item Size Drop Down
    @IBAction func itemSizeTapped(_ sender: UIButton) {
        sizesOutletCollection.forEach { (button) in
            UIView.animate(withDuration: 0.3, animations: {
                button.isHidden = !button.isHidden
                self.view.layoutIfNeeded()
            })
        }
    }
    
    
    @IBAction func selectItemSize(_ sender: UIButton) {
        itemSizeButton.setTitle(sender.titleLabel?.text, for: .normal)
        sizesOutletCollection.forEach { (button) in
            UIView.animate(withDuration: 0.3, animations: {
                button.isHidden = !button.isHidden
                self.view.layoutIfNeeded()
            })
        }
    }
}


